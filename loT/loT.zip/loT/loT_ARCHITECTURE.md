# 远程天文台控制系统架构文档

## 概述

本系统采用模块化设计，将主文件与功能模块分离，提高代码的可维护性和可扩展性。

## 架构设计

### 主文件 (loT.ino)
- **职责**: 全局变量管理、模块初始化、主程序循环
- **内容**:
  - 全局变量定义
  - 库实例化
  - 初始化函数
  - setup() 和 loop() 函数
  - 函数声明（不包含实现）

### 功能模块文件
每个功能模块都有独立的文件，包含：
- 功能函数实现
- Blynk回调函数
- 模块特定的数据处理

## 文件结构

```
IoT/loT/
├── loT.ino                    # 主文件（全局变量、初始化、主循环）
├── settings.h                 # 配置文件（引脚定义、Blynk配置等）
├── INA226.ino                 # INA226电压电流传感器模块
├── DHT11.ino                  # DHT11温湿度传感器模块
├── Rain_Sensor.ino           # 雨水传感器模块
├── Wireless_to_Motor.ino      # 无线发射模块（电机控制）
├── BT_to_Onstep.ino           # 蓝牙控制模块（OnStep控制）
├── mosfet.ino                 # MOSFET控制模块
├── Heater_Control.ino         # 加热片控制模块
└── loT_ARCHITECTURE.md        # 架构文档
```

## 模块详细说明

### 1. INA226.ino - 电压电流传感器
**功能**: 测量输出电压和电流，5次采样平均提高精度
**主要函数**:
- `readOutputVoltageCurrent()` - 读取电压电流数据
- `sendINA226DataToBlynk()` - 发送数据到Blynk
- `printINA226Data()` - 打印调试信息

**Blynk虚拟引脚**:
- V50: 输出电压
- V51: 输出电流

### 2. DHT11.ino - 温湿度传感器
**功能**: 读取DHT11温湿度数据，支持多采样平均提高精度
**主要函数**:
- `readDHT11Data()` - 读取温湿度数据（5次采样平均）
- `sendDHT11DataToBlynk()` - 发送数据到Blynk
- `getDHT11Temperature()` - 获取温度值
- `getDHT11Humidity()` - 获取湿度值

**Blynk虚拟引脚**:
- V40: 温度显示
- V41: 湿度显示
- V42: 温度设置值

### 3. Rain_Sensor.ino - 雨水传感器
**功能**: 检测雨水状态，支持中断检测和模拟量读取
**主要函数**:
- `initRainSensor()` - 初始化雨水传感器
- `readRainSensor()` - 读取雨水传感器模拟量
- `handleRainSensorState()` - 处理雨水传感器状态变化
- `isRainDetected()` - 获取雨水检测状态

**Blynk虚拟引脚**:
- V20: 模拟量输出
- V21: 数字量输出（1=有水，0=无水）

### 4. Wireless_to_Motor.ino - 无线发射模块
**功能**: 通过无线信号控制电机，支持点动和自锁模式
**主要函数**:
- `init()` - 初始化无线发射模块
- `RFSendData()` - 发送无线数据包
- `bit_1()`, `bit_0()` - 发送位数据
- `sendSync()` - 发送同步码

**Blynk回调函数**:
- V30: 正转点动
- V31: 反转点动
- V32: 正转自锁
- V33: 反转自锁

### 5. BT_to_Onstep.ino - 蓝牙控制模块
**功能**: 蓝牙连接OnStep设备，发送控制命令
**主要函数**:
- `pairBluetooth()` - 蓝牙配对
- `sendParkCommand()` - 发送回停放位命令
- `handleBluetoothControl()` - 处理蓝牙控制逻辑
- `isBluetoothConnected()` - 获取蓝牙连接状态
- `isBluetoothPairing()` - 获取蓝牙配对状态

**Blynk回调函数**:
- V60: 蓝牙配对按钮
- V61: 回停放位按钮

### 6. mosfet.ino - MOSFET控制模块
**功能**: 控制MOSFET开关，监控运行时间
**主要函数**:
- `handleMosfetControl()` - 处理MOSFET控制
- `reportMosfetRuntime()` - 上报运行时间

**Blynk回调函数**:
- V70: MOSFET控制按钮
- V71: 运行时间显示

### 7. Heater_Control.ino - 加热片控制模块
**功能**: 控制加热片的开关，支持手动控制和自动温度控制
**主要函数**:
- `initHeater()` - 初始化加热片控制
- `setHeaterState()` - 设置加热片状态
- `updateHeaterControl()` - 更新加热片控制逻辑
- `isHeaterOn()` - 获取加热片状态

**Blynk回调函数**:
- V90: 加热片控制模式（手动/自动）
- V91: 加热片状态
- V92: 温度设置
- V93: 湿度阈值设置
- V94: 温度差值阈值设置

## 配置管理

### settings.h 文件
集中管理所有配置参数：
- Blynk配置（服务器、认证令牌）
- WiFi配置
- 引脚定义
- 虚拟引脚映射
- 模块参数
- 无线控制命令定义（D0-D3）

## 数据流

```
传感器读取 → 数据处理 → Blynk发送 → 远程监控
     ↓
  本地调试输出（串口）
```

## 主程序流程

### setup() 函数
1. 初始化串口通信
2. 初始化所有模块
3. 建立Blynk连接

### loop() 函数
1. 运行Blynk主循环
2. 读取所有传感器数据
3. 处理蓝牙控制逻辑
4. 处理加热片控制逻辑
5. 发送数据到Blynk平台
6. 打印调试信息
7. 延时1秒

## 优势

1. **模块化**: 每个功能独立，便于维护和调试
2. **可扩展**: 新增模块不影响现有代码
3. **配置集中**: 所有配置在settings.h中管理
4. **代码复用**: 功能函数可在不同项目中复用
5. **调试友好**: 每个模块可独立测试，统一使用串口输出调试信息

## 使用说明

1. 修改 `settings.h` 中的配置参数
2. 编译并上传主文件 `loT.ino`
3. 所有功能模块会自动包含在编译中
4. 通过Blynk应用进行远程监控和控制
5. 通过串口监视器查看调试信息

## 注意事项

1. 确保所有引脚定义不冲突
2. Blynk虚拟引脚映射要正确
3. 各模块的全局变量在主文件中定义
4. 功能函数在各模块文件中实现
5. 主文件只负责调用，不包含具体实现
6. 所有调试信息统一通过串口输出
7. 无线控制命令定义在settings.h中统一管理