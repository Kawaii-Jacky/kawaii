# 远程天文台OTA系统使用指南

## 概述

OTA（Over-The-Air）系统允许您通过WiFi网络远程更新ESP32固件，无需物理连接设备。本系统提供了Web界面更新功能，并通过Blynk显示更新进度和固件版本。

**针对ESP32 WROOM 32 (4MB Flash)优化**

## 功能特性

- 🌐 **Web界面更新**：通过浏览器访问设备IP地址进行固件更新
- 📊 **进度显示**：通过Blynk实时显示更新进度
- 🔒 **密码保护**：更新需要输入密码，确保安全性
- 🔄 **自动重启**：更新完成后自动重启设备
- 📋 **版本管理**：显示当前固件版本和编译信息
- ⏱️ **超时保护**：防止更新过程卡死
- 💾 **内存优化**：针对4MB Flash进行分区优化

## 系统配置

### 默认设置
- **OTA端口**：8080
- **主机名**：AstroObservatory
- **更新密码**：Czh040731
- **最大固件大小**：1.875MB（适配Minimal SPIFFS分区表）
- **更新超时时间**：5分钟
- **进度报告间隔**：1秒

### Flash分区配置（ESP32 WROOM 32）
- **总Flash大小**：4MB
- **应用分区**：1.875MB
- **OTA分区**：1.875MB
- **SPIFFS分区**：190KB

### 访问地址
- **IP地址访问**：`http://设备IP:8080`
- **主机名访问**：`http://AstroObservatory.local:8080`

## 使用方法

### Web界面更新

#### 步骤1：准备固件文件
- 确保固件文件为`.bin`格式
- **固件文件大小不超过1.875MB**
- 使用Arduino IDE编译生成的固件文件
- 确保编译时选择了"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"分区表

#### 步骤2：访问OTA界面
1. 确保设备已连接到WiFi网络
2. 在浏览器中输入：`http://设备IP:8080`
3. 或使用主机名：`http://AstroObservatory.local:8080`

#### 步骤3：执行更新
1. 输入更新密码：`astro123`
2. 点击"选择文件"按钮，选择固件文件
3. 点击"开始更新"按钮
4. 等待更新完成，设备将自动重启

### Blynk显示

#### 虚拟引脚配置
- **V74**：OTA更新进度显示（0-100）
- **V76**：固件版本显示

#### 显示内容
- **V74**：实时显示OTA更新进度百分比
- **V76**：显示当前固件版本号

## 安全注意事项

### 密码保护
- 默认更新密码为`astro123`
- 建议在生产环境中修改密码
- 密码存储在`settings.h`文件中

### 网络安全
- OTA服务器仅在本地网络运行
- 确保WiFi网络安全性
- 避免在公共网络中使用

### 固件验证
- 系统会自动验证固件文件完整性
- 更新失败时设备不会重启
- 建议在更新前备份重要数据

### 内存保护
- 固件大小限制为3MB，防止内存溢出
- 更新超时保护，防止过程卡死
- 自动错误恢复机制

## 故障排除

### 常见问题

#### 1. 无法访问OTA界面
**可能原因**：
- 设备未连接到WiFi
- 端口被防火墙阻止
- IP地址错误

**解决方法**：
- 检查WiFi连接状态
- 确认设备IP地址
- 检查防火墙设置

#### 2. 更新失败 - 文件过大
**可能原因**：
- 固件文件超过1.875MB限制
- 编译时分区表配置错误

**解决方法**：
- 检查固件文件大小
- 重新编译时选择"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"分区表
- 优化代码减少固件大小

#### 3. 更新超时
**可能原因**：
- 网络连接不稳定
- 文件传输中断
- 设备内存不足

**解决方法**：
- 检查网络连接
- 重新尝试更新
- 重启设备后重试

#### 4. 设备无法重启
**可能原因**：
- 更新过程中断电
- 固件文件不兼容
- 分区表错误

**解决方法**：
- 重新上电
- 使用串口重新烧录固件
- 检查分区表配置

### 调试信息

#### 串口输出
系统会在串口输出详细的OTA操作信息：
```
=== 初始化OTA系统 ===
OTA Web服务器已启动
访问地址: http://192.168.1.100:8080
主机名: AstroObservatory.local
OTA更新开始
文件大小: 2048576 字节
最大允许大小: 3145728 字节
```

#### Blynk终端
OTA状态会实时发送到Blynk终端：
```
=== OTA系统信息 ===
固件版本: 1.0.0
固件名称: AstroObservatory
编译时间: Dec 15 2024 14:30:25
设备ID: 78:1C:3C:A2:D0:16
IP地址: 192.168.1.100
OTA Web地址: http://192.168.1.100:8080
OTA进度: 45%
```

## 自定义配置

### 修改OTA设置

#### 1. 修改端口
在`settings.h`中修改：
```cpp
#define OTA_PORT 8080  // 修改为其他端口
```

#### 2. 修改主机名
```cpp
#define OTA_HOSTNAME "AstroObservatory"  // 修改主机名
```

#### 3. 修改密码
```cpp
#define OTA_PASSWORD "astro123"  // 修改更新密码
```

#### 4. 修改固件信息
```cpp
#define FIRMWARE_VERSION "1.0.0"  // 修改版本号
#define FIRMWARE_NAME "AstroObservatory"  // 修改固件名称
```

#### 5. 修改Flash配置
```cpp
#define MAX_FIRMWARE_SIZE 0x300000       // 最大固件大小 (3MB)
#define OTA_UPDATE_TIMEOUT 300000        // 更新超时时间 (5分钟)
#define OTA_PROGRESS_INTERVAL 1000       // 进度报告间隔 (1秒)
```

### Arduino IDE分区表配置

为了支持OTA功能，需要在Arduino IDE中配置正确的分区表：

1. 打开Arduino IDE
2. 选择工具 → 分区表 → **"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"**
3. 或者选择 **"4MB (1.2MB APP/1.5MB SPIFFS) with OTA"**

**推荐配置：**
- ✅ **"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"** - 推荐使用，应用空间最大
- ✅ **"4MB (1.2MB APP/1.5MB SPIFFS) with OTA"** - 如果需要更多文件系统空间

**分区表对比：**
```
Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS) - 推荐
├── Bootloader (28KB)
├── 分区表 (4KB)
├── 应用分区 (1.9MB) ← 当前程序
├── OTA分区 (1.9MB) ← 新固件存储
└── SPIFFS (190KB) ← 文件系统

4MB (1.2MB APP/1.5MB SPIFFS) with OTA
├── Bootloader (28KB)
├── 分区表 (4KB)
├── 应用分区 (1.2MB) ← 当前程序
├── OTA分区 (1.2MB) ← 新固件存储
└── SPIFFS (1.5MB) ← 文件系统
```

### 添加新功能

#### 1. 自动版本检查
可以添加检查远程服务器新版本的功能：
```cpp
void checkRemoteVersion() {
    // 实现远程版本检查逻辑
}
```

#### 2. 更新通知
可以添加邮件或消息通知功能：
```cpp
void sendUpdateNotification() {
    // 实现更新通知逻辑
}
```

## 技术细节

### 文件结构
```
IoT/loT/
├── OTA_System.ino          # OTA系统主文件
├── OTA_USAGE_GUIDE.md      # 使用说明文档
├── loT.ino                 # 主程序文件
└── settings.h              # 配置文件（包含OTA配置）
```

### 依赖库
- `WebServer.h`：ESP32 Web服务器
- `Update.h`：ESP32 OTA更新库
- `SPIFFS.h`：文件系统（可选）

### 内存使用
- OTA Web服务器：约50KB RAM
- HTML页面：约15KB Flash
- 更新缓冲区：根据固件大小动态分配
- 最大固件大小：3MB（ESP32 WROOM 32）

### Flash分区布局
```
ESP32 WROOM 32 (4MB Flash) - Minimal SPIFFS
├── Bootloader (28KB)
├── 分区表 (4KB)
├── 应用分区 (1.875MB) ← 当前运行的程序
├── OTA分区 (1.875MB) ← 新固件存储区域
└── SPIFFS (190KB) ← 文件系统
```

## 更新日志

### v1.0.0 (2024-12-15)
- 初始版本发布
- 支持Web界面更新
- 支持Blynk进度显示
- 针对ESP32 WROOM 32优化
- 添加超时保护机制
- 基本安全功能

## 联系支持

如有问题或建议，请通过以下方式联系：
- 项目仓库：GitHub
- 邮箱：support@astroobservatory.com
- 技术文档：项目Wiki

---

**注意**：
1. 使用OTA功能时请确保网络稳定，避免更新过程中断电
2. 固件文件大小不能超过1.875MB
3. 确保Arduino IDE中选择了"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"分区表
4. 建议在更新前备份重要数据 