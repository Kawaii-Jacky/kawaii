# Scripts.ino 自动化脚本使用指南

## 概述
Scripts.ino 是自动化脚本控制模块，整合了自动开关顶和自动打开加热的功能。该模块提供了完整的自动化控制逻辑，包括定时器控制、雨水检测、温度控制等功能。

## 主要功能

### 1. 自动开关顶功能
- **定时器控制**: 支持基于时间、日出、日落的自动开关顶
- **雨水检测**: 检测到雨水时自动关闭圆顶
- **状态管理**: 完整的圆顶状态跟踪和管理

### 2. 自动加热功能
- **温度控制**: 基于UTC温度和DHT11温度的自动加热控制
- **湿度控制**: 基于湿度阈值的加热决策
- **手动/自动模式**: 支持手动和自动两种控制模式

## 功能模块

### 定时器控制模块
```cpp
// 主要函数
void checkTimer();           // 检查定时器状态
void triggerStartTimer();    // 触发开顶定时器
void triggerStopTimer();     // 触发关顶定时器
void resetTimer();           // 重置定时器
bool isTimerEnabled();       // 获取定时器状态
String getTimerInfo();       // 获取定时器信息
```

### 雨水检测模块
```cpp
// 主要函数
void handleRainAction();     // 处理雨水检测动作
void executeRainShutdownSequence();  // 执行雨水关顶序列
bool connectBluetoothForRain();      // 为雨水关顶连接蓝牙
bool setDateTimeForRain();           // 为雨水关顶设置时间
bool unparkForRain();                // 为雨水关顶执行unpark
bool disconnectMosfetForRain();      // 为雨水关顶断开MOSFET
bool executeRainShutdown();          // 执行雨水关顶操作
```

### 加热控制模块
```cpp
// 主要函数
void updateHeaterControl();  // 更新加热控制逻辑
void setHeaterState();       // 设置加热片状态
bool isHeaterOn();           // 获取加热片状态
```

## Blynk虚拟引脚配置

### 定时器控制引脚
- `MOTOR_TIMER_VPIN (V46)`: 定时器时间输入控件
- `MOTOR_TIMER_SWITCH_VPIN (V47)`: 定时器总开关

### 加热控制引脚
- `HEATER_CONTROL_VPIN (V60)`: 加热片控制模式 (0=手动, 1=自动)
- `HEATER_MANUAL_VPIN (V61)`: 手动模式开关 (0=关闭, 1=开启)
- `HEATER_HUMIDITY_SET_VPIN (V62)`: 湿度阈值设置 (0-100)
- `HEATER_TEMP_DIFF_SET_VPIN (V63)`: 温度差值设置 (0-30)
- `HEATER_STATUS_VPIN (V64)`: 加热片状态上报 (0=关闭, 1=开启)
- `UTC_TEMP_SET_VPIN (V59)`: 目标温度设置

## 使用流程

### 1. 初始化
在主程序中调用：
```cpp
initScripts();  // 初始化自动化脚本模块
```

### 2. 定时器设置
1. 在Blynk中设置 `MOTOR_TIMER_SWITCH_VPIN` 为开启状态
2. 使用 `MOTOR_TIMER_VPIN` 设置定时器时间
3. 系统会自动检查时间并执行相应动作

### 3. 加热控制设置
1. 设置 `HEATER_CONTROL_VPIN` 为自动模式
2. 配置 `HEATER_HUMIDITY_SET_VPIN` 湿度阈值
3. 配置 `HEATER_TEMP_DIFF_SET_VPIN` 温度差值
4. 系统会根据温度和湿度自动控制加热片

### 4. 主循环调用
在主循环中调用：
```cpp
checkTimer();        // 检查定时器
handleRainAction();  // 处理雨水检测
```

## 自动化逻辑

### 定时器逻辑
1. **时间检查**: 每秒检查当前时间
2. **星期验证**: 检查今天是否为生效日
3. **触发条件**: 检查是否到达开始/停止时间
4. **动作执行**: 发送相应的电机控制命令
5. **状态更新**: 更新圆顶状态和发送通知

### 雨水检测逻辑
1. **状态检测**: 检测雨水传感器状态变化
2. **条件验证**: 检查自动关顶开关是否开启
3. **动作执行**: 触发关顶命令
4. **通知发送**: 发送Blynk通知和邮件

### 加热控制逻辑
1. **模式检查**: 检查是否为自动模式
2. **湿度判断**: 检查湿度是否超过阈值
3. **温度比较**: 比较UTC温度和DHT11温度差值
4. **加热决策**: 根据条件决定是否开启加热
5. **状态更新**: 更新加热片状态

## 配置参数

### 定时器参数
- `startHour/startMinute`: 开始时间
- `stopHour/stopMinute`: 停止时间
- `weekdays[]`: 生效的星期几
- `timezone`: 时区设置

### 加热参数
- `humidityThreshold`: 湿度阈值 (默认值在settings.h中设置)
- `tempDiffThreshold`: 温度差值阈值 (默认值在settings.h中设置)
- `targetTemp`: 目标温度

## 注意事项

1. **依赖关系**: 需要确保其他模块正确初始化
2. **时间同步**: 确保系统时间正确同步
3. **网络连接**: 确保Blynk连接正常
4. **传感器状态**: 确保所有传感器工作正常

## 故障排除

### 定时器不工作
- 检查时间同步状态
- 验证定时器开关设置
- 确认生效日期配置

### 加热控制异常
- 检查传感器数据有效性
- 验证阈值设置
- 确认控制模式设置

### 雨水检测不响应
- 检查雨水传感器连接
- 验证自动关顶开关状态
- 确认邮件发送功能

## 扩展功能

### 自定义自动化规则
可以在Scripts.ino中添加自定义的自动化规则，例如：
- 基于风速的自动关顶
- 基于云量的自动控制
- 基于时间的加热策略调整

### 多设备协调
可以扩展支持多个设备的协调控制，例如：
- 多个圆顶的同步控制
- 多个加热片的协调工作
- 设备间的状态同步

## 雨水检测流程

### 雨水关顶序列（5个步骤）
当检测到雨水时，系统会按以下顺序执行：

1. **连接蓝牙** (`connectBluetoothForRain`)
   - 检查蓝牙连接状态
   - 如果未连接，尝试连接（10秒超时）
   - 失败则停止流程

2. **设置日期和时间** (`setDateTimeForRain`)
   - 发送日期时间设置命令到OnStep
   - 等待回复（5秒超时）
   - 只有收到"1"回复才继续，否则停止流程

3. **执行unpark** (`unparkForRain`)
   - 发送unpark命令到OnStep
   - 等待回复（5秒超时）
   - 只有收到"1"回复才继续，否则停止流程

4. **断开MOSFET供电** (`disconnectMosfetForRain`)
   - 断开MOSFET控制引脚
   - 更新按钮状态
   - 失败不影响后续步骤

5. **执行关顶** (`executeRainShutdown`)
   - 发送反转点动命令
   - 更新圆顶状态
   - 发送成功/失败通知

### 错误处理机制
- 每个步骤都有超时保护
- 关键步骤失败会停止整个流程
- 非关键步骤失败会继续执行
- 所有操作都有详细的状态反馈 