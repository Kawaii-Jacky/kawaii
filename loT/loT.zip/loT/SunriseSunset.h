/*
 * SunriseSunset.h - 日出日落时间计算
 * 功能：计算指定日期的日出和日落时间
 * 算法：基于太阳位置计算，适用于中纬度地区
 */

#ifndef SUNRISE_SUNSET_H
#define SUNRISE_SUNSET_H

#include "settings.h"
#include <math.h>

// 日出日落计算函数声明
double calculateSunrise(int dayOfYear, double latitude, double longitude, int timezone);
double calculateSunset(int dayOfYear, double latitude, double longitude, int timezone);
int getDayOfYear(int month, int day);
bool isSunriseTime(int currentHour, int currentMinute);
bool isSunsetTime(int currentHour, int currentMinute);
void getSunriseSunsetTime(int month, int day, int* sunriseHour, int* sunriseMinute, int* sunsetHour, int* sunsetMinute);

#endif 